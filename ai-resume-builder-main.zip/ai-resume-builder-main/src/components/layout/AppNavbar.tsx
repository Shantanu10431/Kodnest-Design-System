'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

export default function AppNavbar() {
    const pathname = usePathname();

    const isActive = (path: string) => pathname === path;

    return (
        <nav className="fixed top-0 left-0 right-0 h-[80px] bg-main border-b border-main z-50 px-8 flex items-center justify-between print:hidden">
            <div className="flex items-center gap-8">
                <Link href="/" className="text-xl font-bold tracking-tight text-main" style={{ fontFamily: 'var(--font-serif)' }}>
                    AI Resume Builder
                </Link>
                <div className="h-6 w-px bg-border mx-2"></div>
                <div className="flex items-center gap-6">
                    <Link
                        href="/builder"
                        className={`text-sm font-medium transition-colors ${isActive('/builder') ? 'text-accent' : 'text-muted hover:text-main'}`}
                    >
                        Builder
                    </Link>
                    <Link
                        href="/preview"
                        className={`text-sm font-medium transition-colors ${isActive('/preview') ? 'text-accent' : 'text-muted hover:text-main'}`}
                    >
                        Preview
                    </Link>
                    <Link
                        href="/proof"
                        className={`text-sm font-medium transition-colors ${isActive('/proof') ? 'text-accent' : 'text-muted hover:text-main'}`}
                    >
                        Proof
                    </Link>
                </div>
            </div>

            <div>
                <Link
                    href="/builder"
                    className="px-4 py-2 bg-main border border-main rounded-sm text-sm font-medium text-main hover:bg-card transition-colors"
                >
                    New Resume
                </Link>
            </div>
        </nav>
    );
}
