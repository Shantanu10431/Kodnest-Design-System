import RBLayoutShell from '@/components/layout/RBLayoutShell';

export default function RBLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <RBLayoutShell>
            {children}
        </RBLayoutShell>
    );
}
